<?php

namespace App\Http\Livewire\Blending;

use Livewire\Component;

class Base extends Component
{
    public function render()
    {
        return view('livewire.blending.base');
    }
}
