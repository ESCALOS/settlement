<?php

namespace App\Http\Livewire\Dispatch;

use Livewire\Component;

class Base extends Component
{
    public function render()
    {
        return view('livewire.dispatch.base');
    }
}
