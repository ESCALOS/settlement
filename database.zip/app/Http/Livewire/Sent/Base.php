<?php

namespace App\Http\Livewire\Sent;

use Livewire\Component;

class Base extends Component
{
    public function render()
    {
        return view('livewire.sent.base');
    }
}
