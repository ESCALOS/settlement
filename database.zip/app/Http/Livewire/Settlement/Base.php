<?php

namespace App\Http\Livewire\Settlement;

use Livewire\Component;

class Base extends Component
{
    public function render()
    {
        return view('livewire.settlement.base');
    }
}
