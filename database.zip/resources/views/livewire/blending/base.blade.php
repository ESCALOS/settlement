<div>
    <x-header-crud button="0">Blending</x-header-crud>
    <div class="p-4">
        <livewire:blending.blending-table>
    </div>

    <livewire:blending.modal>
    <livewire:blending.preview>
    <livewire:settlement.modal>
    <livewire:settlement.detail>
</div>
