<div>
    <x-header-crud button="0">Pendientes a enviar</x-header-crud>
    <div class="p-4">
        <livewire:dispatch.dispatch-table>
    </div>
    <livewire:blending.modal>
    <livewire:blending.preview>
</div>
