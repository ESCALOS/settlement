<div>
    <x-header-crud button="0" >Mezclas enviadas</x-header-crud>
    <div class="p-4">
        <livewire:sent.sent-table>
    </div>
    <livewire:blending.preview>
</div>
