<div>
    <x-header-crud button="0">Liquidaciones</x-header-crud>
    <div class="p-4">
        <livewire:settlement.settlement-table>
    </div>
    <livewire:settlement.modal>
    <livewire:settlement.detail>
</div>
