<div class="">
            <div class="flex justify-between items-end mb-1">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400" for="9139b514cf11c7507b00f02750a4ce86">
    Deducción Oro
</label>
            
                    </div>
    
    <div class="relative rounded-md  shadow-sm ">
        
        <input type="number" autocomplete="off" class="placeholder-secondary-400 dark:bg-secondary-800 dark:text-secondary-400 dark:placeholder-secondary-500 border border-secondary-300 focus:ring-primary-500 focus:border-primary-500 dark:border-secondary-600 form-input block w-full sm:text-sm rounded-md transition ease-in-out duration-100 focus:outline-none shadow-sm" wire:model.defer="requirement.deduction.gold" name="requirement.deduction.gold" id="9139b514cf11c7507b00f02750a4ce86" />

            </div>

    
                </div>
<?php /**PATH D:\Documentos\proyects\settlement\storage\framework\views/354c1e60e82c3d9df68a9bcc28f1c409.blade.php ENDPATH**/ ?>