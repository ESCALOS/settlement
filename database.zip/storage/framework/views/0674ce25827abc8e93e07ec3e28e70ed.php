<div class="">
            <div class="flex justify-between items-end mb-1">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400" for="bb100c7a27167c34d8b907aaff7e5b92">
    Estibadores
</label>
            
                    </div>
    
    <div class="relative rounded-md  shadow-sm ">
        
        <input type="number" autocomplete="off" class="placeholder-secondary-400 dark:bg-secondary-800 dark:text-secondary-400 dark:placeholder-secondary-500 border border-secondary-300 focus:ring-primary-500 focus:border-primary-500 dark:border-secondary-600 form-input block w-full sm:text-sm rounded-md transition ease-in-out duration-100 focus:outline-none shadow-sm" wire:model.defer="requirement.other.stevedore" name="requirement.other.stevedore" id="bb100c7a27167c34d8b907aaff7e5b92" />

            </div>

    
                </div>
<?php /**PATH D:\Documentos\proyects\settlement\storage\framework\views/71efdb7ca4105dfc780c328e2f1cb8a2.blade.php ENDPATH**/ ?>