<button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded-full gap-x-2 text-sm px-4 py-2     ring-cyan-500 text-white bg-cyan-500 hover:bg-cyan-600 hover:ring-cyan-600
    dark:ring-offset-slate-800 dark:bg-cyan-700 dark:ring-cyan-700
    dark:hover:bg-cyan-600 dark:hover:ring-cyan-600" wire:click="openImportModal">
            <svg class="w-4 h-4 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
</svg>
    
    Importar

    
    </button>
