<button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded-full w-9 h-9     ring-positive-500 text-white bg-positive-500 hover:bg-positive-600 hover:ring-positive-600
    dark:ring-offset-slate-800 dark:bg-positive-700 dark:ring-positive-700
    dark:hover:bg-positive-600 dark:hover:ring-positive-600" title="Enviar" x-on:confirm="{
            title: '¿Seguro de enviar?',
            icon: 'warning',
            accept: {
                label: 'Sí',
                method: 'ship',
                params: '13'
            },
            reject: {
                label: 'No',
            }
        }">
    <div >
                    <svg class="w-4 h-4 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
</svg>
            </div>

    </button>
<?php /**PATH D:\Documentos\proyects\settlement\storage\framework\views/54ab39ddb22f955cb230908113ef2c64.blade.php ENDPATH**/ ?>