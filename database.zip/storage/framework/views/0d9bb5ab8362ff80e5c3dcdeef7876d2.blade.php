<button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded gap-x-2 text-sm px-4 py-2     ring-warning-500 text-white bg-warning-500 hover:bg-warning-600 hover:ring-warning-600
    dark:ring-offset-slate-800 dark:bg-warning-700 dark:ring-warning-700
    dark:hover:bg-warning-600 dark:hover:ring-warning-600" method="ship" params="3">
    
    Sí

    
    </button>
