<div class="">
            <div class="flex justify-between items-end mb-1">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400" for="4aee67d6a4f1d5befa2322981d564e7f">
    Factor:
</label>
            
                    </div>
    
    <div class="relative rounded-md  shadow-sm ">
        
        <input type="number" autocomplete="off" class="placeholder-secondary-400 dark:bg-secondary-800 dark:text-secondary-400 dark:placeholder-secondary-500 border border-secondary-300 focus:ring-primary-500 focus:border-primary-500 dark:border-secondary-600 form-input block w-full sm:text-sm rounded-md transition ease-in-out duration-100 focus:outline-none shadow-sm" wire:model.defer="law.silverFactor" name="law.silverFactor" id="4aee67d6a4f1d5befa2322981d564e7f" />

            </div>

    
                </div>
