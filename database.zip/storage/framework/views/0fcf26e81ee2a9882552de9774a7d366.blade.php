<div class="">
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400 mb-1" for="e5f96ae00443877315fbb64fd3d90005">
    Factura
</label>
    
    <select class="form-select block w-full pl-3 pr-10 py-2 text-base sm:text-sm shadow-sm
                rounded-md border bg-white focus:ring-1 focus:outline-none
                dark:bg-secondary-800 dark:border-secondary-600 dark:text-secondary-400 border-secondary-300 focus:ring-primary-500 focus:border-primary-500" wire:model="invoice" name="invoice" id="e5f96ae00443877315fbb64fd3d90005">
                    
                            <option value="1"
                    >
                    Sí
                </option>
                            <option value="0"
                    >
                    No
                </option>
                        </select>

    
                </div>
