<button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded-full w-9 h-9     ring-blue-500 text-white bg-blue-500 hover:bg-blue-600 hover:ring-blue-600
    dark:ring-offset-slate-800 dark:bg-blue-700 dark:ring-blue-700
    dark:hover:bg-blue-600 dark:hover:ring-blue-600" title="Liquidar" wire:click="openSettlement(14)">
    <div                             wire:target="openSettlement"
                        wire:loading.remove
        >
                    <svg class="w-4 h-4 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
</svg>
            </div>

            <svg class="animate-spin w-4 h-4 shrink-0"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
                            wire:target="openSettlement"
                        wire:loading.delay>
            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
    </button>
<?php /**PATH D:\Documentos\proyects\settlement\storage\framework\views/cfed3bdb2766f0e224e6de8b3c4c8758.blade.php ENDPATH**/ ?>