<button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded-full gap-x-2 text-sm px-4 py-2     ring-positive-500 text-white bg-positive-500 hover:bg-positive-600 hover:ring-positive-600
    dark:ring-offset-slate-800 dark:bg-positive-700 dark:ring-positive-700
    dark:hover:bg-positive-600 dark:hover:ring-positive-600" wire:click="$emit('openModal',0)">
            <svg class="w-4 h-4 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
</svg>
    
    Registrar

    
    </button>
<?php /**PATH D:\Documentos\proyects\settlement\storage\framework\views/5943889ee4e7f32bcfc2bc414ad03d59.blade.php ENDPATH**/ ?>