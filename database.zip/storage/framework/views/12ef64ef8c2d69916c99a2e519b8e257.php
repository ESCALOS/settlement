<button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded gap-x-2 text-sm px-4 py-2     ring-negative-500 text-white bg-negative-500 hover:bg-negative-600 hover:ring-negative-600
    dark:ring-offset-slate-800 dark:bg-negative-700 dark:ring-negative-700
    dark:hover:bg-negative-600 dark:hover:ring-negative-600" method="delete" params="4">
    
    Sí

    
    </button>
<?php /**PATH D:\Documentos\proyects\settlement\storage\framework\views/645cf57d2e0697b7aee712bfacb37a4f.blade.php ENDPATH**/ ?>