<button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded-full w-9 h-9     ring-sky-500 text-white bg-sky-500 hover:bg-sky-600 hover:ring-sky-600
    dark:ring-offset-slate-800 dark:bg-sky-700 dark:ring-sky-700
    dark:hover:bg-sky-600 dark:hover:ring-sky-600" title="Ver" wire:click="$emitTo('settlement.modal','openModal',4)">
    <div >
                    <svg class="w-4 h-4 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
</svg>
            </div>

    </button>
<?php /**PATH D:\Documentos\proyects\settlement\storage\framework\views/9b36571e0c21fe224446091ca48d73bd.blade.php ENDPATH**/ ?>