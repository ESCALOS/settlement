<button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded-full w-9 h-9     ring-negative-500 text-white bg-negative-500 hover:bg-negative-600 hover:ring-negative-600
    dark:ring-offset-slate-800 dark:bg-negative-700 dark:ring-negative-700
    dark:hover:bg-negative-600 dark:hover:ring-negative-600" title="Anular Envío" x-on:confirm="{
        title: '¿Seguro de anular el envío?',
        icon: 'warning',
        accept: {
            label: 'Sí',
            method: 'unship',
            params: '4'
        },
        reject: {
            label: 'No',
        }
    }">
    <div >
                    <svg class="w-4 h-4 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
</svg>
            </div>

    </button>
<?php /**PATH D:\Documentos\proyects\settlement\storage\framework\views/c7b71c2f89ec63ba1d1f6bee9f7f369a.blade.php ENDPATH**/ ?>