<div class="">
            <div class="flex justify-between items-end mb-1">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400" for="723f4e4e5089140f63ed8650b9495ba1">
    TMH a mezclar
</label>
            
                    </div>
    
    <div class="relative rounded-md  shadow-sm ">
        
        <input type="text" autocomplete="off" class="placeholder-secondary-400 dark:bg-secondary-800 dark:text-secondary-400 dark:placeholder-secondary-500 border border-secondary-300 focus:ring-primary-500 focus:border-primary-500 dark:border-secondary-600 form-input block w-full sm:text-sm rounded-md transition ease-in-out duration-100 focus:outline-none shadow-sm" wire:model.debounce.500ms="settlements.1.wmt_to_blending" name="settlements.1.wmt_to_blending" id="723f4e4e5089140f63ed8650b9495ba1" />

            </div>

    
                </div>
<?php /**PATH D:\Documentos\proyects\settlement\storage\framework\views/625c609a8111f49d8f2bc6c91cb4e476.blade.php ENDPATH**/ ?>